﻿
# path setting (override via env vars EVAL_FILE_PATH / EVAL_SHEET_NAME; defaults are the original placeholders)
import os as _os
FILE_PATH = _os.environ.get('EVAL_FILE_PATH', r'C:\Users')
SHEET_NAME = _os.environ.get('EVAL_SHEET_NAME', 'sheetname')


COL_GT = 'Ground Truth'
COL_ANS = 'LLM Answer'
COL_STRAT = 'Retrieval Strategy'
COL_LLM = 'LLM Model'
COL_TIME = 'Time (seconds)'
VIS_COL_TASKAWARE = 'Taskawareprompt_LLM Answer'
VIS_COL_GENERIC = 'genericprompt_LLM Answer'



import pandas as pd
from bert_score import score
import os
import re
import math

TASK_MODES = {
    'ATTRIBUTE_RETRIEVAL': 'numbers',
    'CLASSIFICATION': 'labels',
    'COMPARISON': 'numbers',
    'COMPUTATION': 'numbers',
    'FILTERING': 'numbers_codes',
    'PROXIMITY': 'voxel_ids',
    'REASONING': 'numbers',
    'SUMMARIZATION': 'numbers',
    'VISUALIZATION': 'vis_ids',
}

W_EM, W_BERT = 0.6, 0.4
EM_MODE = 'fraction'          
NUM_REL_TOL = 0.0             
SHOW_TRACE_ROWS = 5

NUM_RE = re.compile(r'(?<![\w.])-?\d+(?:,\d{3})*(?:\.\d+)?(?:[eE][-+]?\d+)?')
ID_RE = re.compile(r'\bv_M\d+_\d+\b', re.I)
CODE_RE = re.compile(r'\b[MS]\d+\b', re.I)
COUNT_RE = re.compile(r'(\d+)\s+neighbou?rs', re.I)
LABEL_RE = re.compile(r'\b(low|medium|high)\b', re.I)
MATERIAL_RE = re.compile(r'\b(sand|gravel|silt|clay|rock|peat|loam)\b', re.I)
TRAILER_RE = re.compile(r'VOXEL_IDS:[^\n]*', re.I)


def norm(text):
    return re.sub(r'\s+', ' ', str(text).replace('"', ' ')).strip()


def tidy(rest):
    rest = re.sub(r'\s+', ' ', rest).strip(' :,;-.')
    return rest if re.search(r'[A-Za-z]', rest) else ''


def extract(task, text):
    """Return (EM items, text part for BERT). Voxel IDs and the VOXEL_IDS line stay in the text part."""
    mode = TASK_MODES.get(task, 'numbers')
    text = str(text)
    m = TRAILER_RE.search(text)
    main = norm(text[:m.start()]) if m else norm(text)
    trailer = norm(m.group(0)) if m else ''


    if mode == 'vis_ids':
        
        src = trailer if trailer else main
        items = sorted(set(i.lower() for i in ID_RE.findall(src)))
        rest_main = ID_RE.sub(' ', main)
        return items, tidy(rest_main)

    if mode == 'voxel_ids':
        ids = [i.lower() for i in ID_RE.findall(main)]
        if ids and re.match(r'(?i)direct neighbou?rs of', main):
            ids = ids[1:]                         
        items = sorted(set(ids))
        c = COUNT_RE.search(main)
        if c:
            items.append(f'count={c.group(1)}')
        rest_main = ID_RE.sub(' ', COUNT_RE.sub('neighbors', main))
    elif mode == 'labels':
        items, last = [], None
        for t in re.finditer(r'\bv_M\d+_\d+\b|\b(?:low|medium|high)\b', main, re.I):
            tok = t.group(0).lower()
            if tok.startswith('v_'):
                last = tok
            else:
                items.append(f'{last}={tok}' if last else tok)
                last = None
        rest_main = LABEL_RE.sub(' ', main)
    else:
        items = [float(n.replace(',', '')) for n in NUM_RE.findall(main)]
        rest_main = NUM_RE.sub(' ', main)
        if task == 'COMPARISON':
            mats = [w.lower() for w in MATERIAL_RE.findall(rest_main)]
            items = mats + items
            rest_main = MATERIAL_RE.sub(' ', rest_main)
        if mode == 'numbers_codes':
            items = [c.upper() for c in CODE_RE.findall(rest_main)] + items
            rest_main = CODE_RE.sub(' ', rest_main)

    return items, tidy(rest_main + ' ' + trailer)


def _same(a, b):
    if isinstance(a, float) and isinstance(b, float):
        return math.isclose(a, b, rel_tol=NUM_REL_TOL, abs_tol=1e-9)
    return a == b


def em_score(gt_items, pred_items, penalize_extras=False, ordered=False):
    if not gt_items:
        return float('nan')        
    denom = max(len(gt_items), len(pred_items)) if penalize_extras else len(gt_items)
    if ordered:
        hit = sum(_same(g, p) for g, p in zip(gt_items, pred_items))
    else:
        left, hit = list(pred_items), 0
        for g in gt_items:
            for k, p in enumerate(left):
                if _same(g, p):
                    hit += 1
                    del left[k]
                    break
    if EM_MODE == 'strict':
        return float(hit == denom)
    return hit / denom


def hybrid_accuracy(em, bf, gt_has_items=True, pred_has_items=True):
    bf = float('nan') if pd.isna(bf) else max(0.0, min(1.0, bf))
    if gt_has_items and not pred_has_items:
        return 0.0     
    if not pd.isna(em) and not pd.isna(bf):
        return W_EM * em + W_BERT * bf
    if not pd.isna(em):
        return em
    return bf


def calc_string(em, bf):
    bf = float('nan') if pd.isna(bf) else max(0.0, min(1.0, bf))
    if pd.isna(em) and pd.isna(bf):
        return 'n/a'
    if pd.isna(bf):
        return f'EM only = {em:.3f}'
    if pd.isna(em):
        return f'BERT only = {bf:.3f}'
    return f'{W_EM}*{em:.3f} + {W_BERT}*{bf:.3f} = {W_EM * em + W_BERT * bf:.3f}'


def score_rows(task, df, gt_col, ans_col):
    """The steps of calculate_semantic_accuracy() in the article's scoring script,
    applied to the rows of one sheet of one task."""
    mode = TASK_MODES.get(task, 'numbers')
    print("\n" + "#" * 70)
    print(f"task={task} | mode={mode} | rows={len(df)}")
    print("#" * 70)
    df = df.reset_index(drop=True).copy()

    gt = [extract(task, x) for x in df[gt_col]]
    pr = [extract(task, x) for x in df[ans_col]]
    df['GT_EM_Items'] = [str(g[0]) for g in gt]
    df['Pred_EM_Items'] = [str(p[0]) for p in pr]
    df['GT_Text'] = [g[1] for g in gt]
    df['Pred_Text'] = [p[1] for p in pr]

    penalize = (mode in ('voxel_ids', 'vis_ids'))

    ordered = False
    df['EM'] = [em_score(g[0], p[0], penalize, ordered) for g, p in zip(gt, pr)]

    for c in ['BERTScore_Precision', 'BERTScore_Recall', 'BERTScore_F1']:
        df[c] = float('nan')
    idx = [i for i, g in enumerate(gt) if g[1]]
    print(f"Calculating BERTScore for {len(idx)} text parts...")
    if idx:
        P, R, F1 = score(
            [pr[i][1] or '.' for i in idx],
            [gt[i][1] for i in idx],
            lang='en',
            rescale_with_baseline=True,
            verbose=True
        )
        df.loc[idx, 'BERTScore_Precision'] = P.tolist()
        df.loc[idx, 'BERTScore_Recall'] = R.tolist()
        df.loc[idx, 'BERTScore_F1'] = F1.tolist()

    df['Hybrid_Acc'] = [hybrid_accuracy(e, b, bool(g[0]), bool(p[0]))
                        for e, b, g, p in zip(df['EM'], df['BERTScore_F1'], gt, pr)]
    df['Calculation'] = [('REFUSAL/NO CORE ANSWER = 0.000' if (g[0] and not p[0]) else calc_string(e, b))
                         for e, b, g, p in zip(df['EM'], df['BERTScore_F1'], gt, pr)]
    print(f"Overall Accuracy ({W_EM}*EM + {W_BERT}*BERT-F1): {df['Hybrid_Acc'].mean():.4f}")
    return df

def summary(df, with_time):
    strat = df[COL_STRAT].astype(str).str.strip() if COL_STRAT in df.columns else 'LLM only'
    g = pd.DataFrame({'Strategy': strat, 'LLM': df[COL_LLM].astype(str).str.strip(),
                      'Accuracy (%)': df['Hybrid_Acc'] * 100})
    if with_time:
        g['Avg time (s)'] = pd.to_numeric(df[COL_TIME], errors='coerce')
    res = g.groupby(['Strategy', 'LLM']).mean().reset_index()
    res['Accuracy (%)'] = res['Accuracy (%)'].round(2)
    if with_time:
        res['Avg time (s)'] = res['Avg time (s)'].round(3)
    return res


def main():
    base_name = os.path.splitext(os.path.basename(FILE_PATH))[0]
    task = base_name.upper().replace('_ANSWERS', '')
    if task not in TASK_MODES:
        print(f"Warning: task '{task}' not in TASK_MODES, using 'numbers'")

    df = pd.read_excel(FILE_PATH, sheet_name=SHEET_NAME, engine='openpyxl')
    df.columns = [str(c).strip() for c in df.columns]
    df = df.dropna(how='all').reset_index(drop=True)
    print(f"{os.path.basename(FILE_PATH)} / {SHEET_NAME}: {len(df)} rows | task={task}")

    if task == 'VISUALIZATION':
        results = []
        for label, col in [('Task-aware', VIS_COL_TASKAWARE), ('Generic', VIS_COL_GENERIC)]:
            s = score_rows(task, df, COL_GT, col)
            results.append((label, s['Hybrid_Acc'].mean() * 100))
        print("\n=== Results ===")
        for label, acc in results:
            print(f"{label:11} Accuracy {acc:.2f} %")
        return

    with_time = (SHEET_NAME == 'Baseline_responses') and (COL_TIME in df.columns)
    s = score_rows(task, df, COL_GT, COL_ANS)
    res = summary(s, with_time)
    pd.set_option('display.width', 200)
    print("\n=== Results ===")
    print(res.to_string(index=False))
    print(f"\nAll rows: Accuracy {s['Hybrid_Acc'].mean() * 100:.2f} %")


if __name__ == "__main__":
    main()
